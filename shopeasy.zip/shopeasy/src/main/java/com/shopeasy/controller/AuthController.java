package com.shopeasy.controller;

import com.shopeasy.model.User;
import com.shopeasy.security.JwtCookieService;
import com.shopeasy.security.JwtUtils;
import com.shopeasy.service.UserService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final JwtCookieService jwtCookieService;

    // AuthenticationManager constructor injection
    public AuthController(UserService userService, 
                         AuthenticationManager authenticationManager,
                         JwtUtils jwtUtils, 
                         JwtCookieService jwtCookieService) {
        this.userService = userService;
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
        this.jwtCookieService = jwtCookieService;
    }

    @GetMapping("/signup")
    public String showSignupForm(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("activePage", "register");
        return "signup";
    }

    @PostMapping("/signup")
    public String registerUser(@Valid @ModelAttribute("user") User user,
                               BindingResult result,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        
        // email validator here if email is wrong 
        // error - message -> wrong email
        //activePage", "register"
        // return signup page
        if (userService.emailExists(user.getEmail())) { // call to service html->controller->service
            result.rejectValue("email", "error.user", "An account with this email already exists");
        }

        if (result.hasErrors()) {
            model.addAttribute("activePage", "register");
            return "signup";
        }

        try {
            userService.registerUser(user);
            redirectAttributes.addFlashAttribute("successMessage", "Registration successful! Please login.");
            return "redirect:/login"; /// BUG not redirecting to login page -> alot will take if i want to redirect to login -> jWT
        } catch (Exception e) {
            model.addAttribute("errorMessage", "Registration failed. Please try again.");
            model.addAttribute("activePage", "register");
            return "signup";
        }
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        HttpServletResponse response,
                        RedirectAttributes redirectAttributes) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, password)
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);
            
            String jwt = jwtUtils.generateToken(email);
            jwtCookieService.createJwtCookie(response, jwt);

            return "redirect:/";
        } catch (AuthenticationException e) {
            redirectAttributes.addAttribute("error", true);
            return "redirect:/login";
        }
    }

    @PostMapping("/logout")
    public String logout(HttpServletResponse response, RedirectAttributes redirectAttributes) {
        SecurityContextHolder.clearContext();
        jwtCookieService.clearJwtCookie(response);
        redirectAttributes.addAttribute("logout", true);
        return "redirect:/login";
    }
}
