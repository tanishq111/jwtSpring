package com.shopeasy.controller;

import com.shopeasy.model.Product;
import com.shopeasy.repository.CategoryRepository;
import com.shopeasy.repository.ProductRepository;
import com.shopeasy.service.WishlistService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Set;
import org.springframework.security.core.Authentication;

@Controller
public class HomeController {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final WishlistService wishlistService;

    public HomeController(ProductRepository productRepository, CategoryRepository categoryRepository, WishlistService wishlistService) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
        this.wishlistService = wishlistService;
    }

    @GetMapping("/")
    public String home(Model model,
                       @RequestParam(required = false) String search,
                       @RequestParam(required = false) Long categoryId,
                       @RequestParam(defaultValue = "0") int page,
                       @RequestParam(defaultValue = "8") int size,
                       Authentication authentication) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Product> productsPage;

        if (search != null && !search.isEmpty()) {
            productsPage = productRepository.findByNameContainingIgnoreCase(search, pageable);
        } else if (categoryId != null) {
            productsPage = productRepository.findByCategoryId(categoryId, pageable);
        } else {
            productsPage = productRepository.findAll(pageable);
        }

        Set<Long> wishlistIds = Set.of();
        if (authentication != null) {
            wishlistIds = wishlistService.getWishlistProductIds(authentication.getName());
        }

        model.addAttribute("products", productsPage.getContent());
        model.addAttribute("page", productsPage);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", productsPage.getTotalPages());
        model.addAttribute("search", search);
        model.addAttribute("categoryId", categoryId);
        model.addAttribute("wishlistIds", wishlistIds);
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("activePage", "home");
        return "index";
    }

    @GetMapping("/product/{id}")
    public String productDetails(@PathVariable Long id, Model model, Authentication authentication) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new com.shopeasy.exception.ProductNotFoundException("Product not found with id: " + id));
        boolean inWishlist = false;
        if (authentication != null) {
            inWishlist = wishlistService.getWishlistProductIds(authentication.getName()).contains(id);
        }
        model.addAttribute("product", product);
        model.addAttribute("inWishlist", inWishlist);
        return "product-details";
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("activePage", "login");
        return "login";
    }
}
