package com.shopeasy.controller;

import com.shopeasy.model.Product;
import com.shopeasy.repository.CategoryRepository;
import com.shopeasy.repository.ProductRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class HomeController {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    public HomeController(ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    @GetMapping("/")
    public String home(Model model, 
                       @RequestParam(required = false) String search,
                       @RequestParam(required = false) Long categoryId) {
        List<Product> products;

        if (search != null && !search.isEmpty()) {
            products = productRepository.findByNameContainingIgnoreCase(search);
        } else if (categoryId != null) {
            products = productRepository.findByCategoryId(categoryId);
        } else {
            products = productRepository.findAll();
        }

        model.addAttribute("products", products); // the products i will get from db will be shown to user
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("activePage", "home"); 
        return "index";
    }

    @GetMapping("/product/{id}")
    public String productDetails(@PathVariable Long id, Model model) {
        Product product = productRepository.findById(id) // wrong pattern
                .orElseThrow(() -> new com.shopeasy.exception.ProductNotFoundException("Product not found with id: " + id));
        model.addAttribute("product", product); // this will search the DB and get the product details
        return "product-details";
    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("activePage", "login");
        return "login";
    }
}
