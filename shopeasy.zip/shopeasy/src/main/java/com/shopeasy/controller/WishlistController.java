package com.shopeasy.controller;

import com.shopeasy.model.Product;
import com.shopeasy.service.WishlistService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping("/wishlist")
public class WishlistController {

    private final WishlistService wishlistService;

    public WishlistController(WishlistService wishlistService) {
        this.wishlistService = wishlistService;
    }

    @GetMapping // "/wishlist page"
    public String viewWishlist(Model model, Authentication authentication) {
        if (authentication == null) {
            return "redirect:/login";
        }
        String email = authentication.getName();
        Set<Product> products = wishlistService.getProducts(email);
        model.addAttribute("wishlistItems", products);
        model.addAttribute("activePage", "wishlist");
        return "wishlist";
    }

    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> add(@RequestParam Long productId,
                                                   Authentication authentication) {
        Map<String, Object> res = new HashMap<>();
        if (authentication == null) {
            res.put("success", false);
            res.put("redirect", "/login");
            return ResponseEntity.status(401).body(res);
        }
        String email = authentication.getName();
        wishlistService.addProduct(email, productId);
        res.put("success", true);
        res.put("message", "Added to wishlist");
        res.put("ids", wishlistService.getWishlistProductIds(email));
        return ResponseEntity.ok(res);
    }

    @PostMapping("/remove")
    public ResponseEntity<Map<String, Object>> remove(@RequestParam Long productId,
                                                      Authentication authentication) {
        Map<String, Object> res = new HashMap<>();
        if (authentication == null) {
            res.put("success", false);
            res.put("redirect", "/login");
            return ResponseEntity.status(401).body(res);
        }
        String email = authentication.getName();
        wishlistService.removeProduct(email, productId);
        res.put("success", true);
        res.put("message", "Removed from wishlist");
        res.put("ids", wishlistService.getWishlistProductIds(email));
        return ResponseEntity.ok(res);
    }
}
