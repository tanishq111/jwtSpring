package com.shopeasy.controller;

import com.shopeasy.model.Cart;
import com.shopeasy.service.CartService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public String viewCart(Model model, Authentication authentication) {
        if (authentication == null) {
            return "redirect:/login";
        }

        String userEmail = authentication.getName();
        Optional<Cart> cart = cartService.getCart(userEmail); // everytime i go to cart page it will fetch the cart details
        
        model.addAttribute("cart", cart.orElse(null));
        model.addAttribute("cartItems", cart.map(Cart::getItems).orElse(List.of()));
        model.addAttribute("cartTotal", cart.map(Cart::getTotalPrice).orElse(0.0));
        model.addAttribute("activePage", "cart");
        
        return "cart";
    }

    @PostMapping("/add")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> addToCart(
            @RequestParam Long productId,
            @RequestParam(defaultValue = "1") Integer quantity,
            Authentication authentication) {
        
        Map<String, Object> response = new HashMap<>();
        
        if (authentication == null) {
            response.put("success", false);
            response.put("message", "Please login to add items to cart");
            response.put("redirect", "/login");
            return ResponseEntity.status(401).body(response);
        }

        try {
            String userEmail = authentication.getName();
            Cart cart = cartService.addToCart(userEmail, productId, quantity);
            
            response.put("success", true);
            response.put("message", "Item added to cart");
            response.put("cartCount", cart.getTotalItems());
            response.put("cartTotal", cart.getTotalPrice());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to add item: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/update")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> updateQuantity(
            @RequestParam Long productId,
            @RequestParam Integer quantity,
            Authentication authentication) {
        
        Map<String, Object> response = new HashMap<>();
        
        if (authentication == null) {
            response.put("success", false);
            response.put("message", "Please login");
            return ResponseEntity.status(401).body(response);
        }

        try {
            String userEmail = authentication.getName();
            Cart cart = cartService.updateCartItemQuantity(userEmail, productId, quantity);
            
            response.put("success", true);
            response.put("message", "Cart updated");
            response.put("cartCount", cart.getTotalItems());
            response.put("cartTotal", cart.getTotalPrice());
            
            cart.getItems().stream()
                .filter(item -> item.getProduct().getId().equals(productId))
                .findFirst()
                .ifPresent(item -> response.put("itemSubtotal", item.getSubtotal()));
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to update: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/remove")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> removeFromCart(
            @RequestParam Long productId,
            Authentication authentication) {
        
        Map<String, Object> response = new HashMap<>();
        
        if (authentication == null) {
            response.put("success", false);
            response.put("message", "Please login");
            return ResponseEntity.status(401).body(response);
        }

        try {
            String userEmail = authentication.getName();
            Cart cart = cartService.removeFromCart(userEmail, productId);
            
            response.put("success", true);
            response.put("message", "Item removed from cart");
            response.put("cartCount", cart.getTotalItems());
            response.put("cartTotal", cart.getTotalPrice());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to remove: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PostMapping("/clear")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> clearCart(Authentication authentication) {
        Map<String, Object> response = new HashMap<>();
        
        if (authentication == null) {
            response.put("success", false);
            response.put("message", "Please login");
            return ResponseEntity.status(401).body(response);
        }

        try {
            String userEmail = authentication.getName();
            cartService.clearCart(userEmail);
            
            response.put("success", true);
            response.put("message", "Cart cleared");
            response.put("cartCount", 0);
            response.put("cartTotal", 0.0);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("message", "Failed to clear cart: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @GetMapping("/count")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> getCartCount(Authentication authentication) {
        Map<String, Object> response = new HashMap<>();
        
        if (authentication == null) {
            response.put("count", 0);
            return ResponseEntity.ok(response);
        }

        String userEmail = authentication.getName();
        response.put("count", cartService.getCartItemCount(userEmail));
        response.put("total", cartService.getCartTotal(userEmail));
        
        return ResponseEntity.ok(response);
    }
}
