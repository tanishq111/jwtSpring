package com.shopeasy.service;

import com.shopeasy.model.Product;
import com.shopeasy.model.User;
import com.shopeasy.model.Wishlist;
import com.shopeasy.repository.ProductRepository;
import com.shopeasy.repository.UserRepository;
import com.shopeasy.repository.WishlistRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
@Transactional
public class WishlistService {

    private final WishlistRepository wishlistRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;

    public WishlistService(WishlistRepository wishlistRepository,
                           UserRepository userRepository,
                           ProductRepository productRepository) {
        this.wishlistRepository = wishlistRepository;
        this.userRepository = userRepository;
        this.productRepository = productRepository;
    }

    public Wishlist getOrCreateWishlist(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Optional<Wishlist> existing = wishlistRepository.findByUser(user);
        if (existing.isPresent()) {
            return existing.get();
        }
        Wishlist wishlist = new Wishlist(user);
        return wishlistRepository.save(wishlist);
    }

    public Set<Long> getWishlistProductIds(String userEmail) {
        Wishlist wishlist = getOrCreateWishlist(userEmail);
        Set<Long> ids = new HashSet<>();
        wishlist.getProducts().forEach(p -> ids.add(p.getId()));
        return ids;
    }

    public Wishlist addProduct(String userEmail, Long productId) {
        Wishlist wishlist = getOrCreateWishlist(userEmail);
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        wishlist.addProduct(product);
        return wishlistRepository.save(wishlist);
    }

    public Wishlist removeProduct(String userEmail, Long productId) {
        Wishlist wishlist = getOrCreateWishlist(userEmail);
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        wishlist.removeProduct(product);
        return wishlistRepository.save(wishlist);
    }

    public Set<Product> getProducts(String userEmail) {
        Wishlist wishlist = getOrCreateWishlist(userEmail);
        return Collections.unmodifiableSet(wishlist.getProducts());
    }
}
