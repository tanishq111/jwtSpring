package com.shopeasy;

import com.shopeasy.model.Category;
import com.shopeasy.model.Product;
import com.shopeasy.repository.CategoryRepository;
import com.shopeasy.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
public class DataSeeder implements CommandLineRunner {


    // it will if we are fetching some initial data from database
    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;

    public DataSeeder(CategoryRepository categoryRepository, ProductRepository productRepository) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        if (categoryRepository.count() == 0) {
            Category electronics = new Category("Electronics");
            Category fashion = new Category("Fashion");
            Category home = new Category("Home");
            Category sports = new Category("Sports");
            Category books = new Category("Books");

            categoryRepository.saveAll(Arrays.asList(electronics, fashion, home, sports, books));

            // Electronics
            Product p1 = new Product("Smartphone", "Latest model smartphone with high res camera", 699.99, "https://placehold.co/300x200?text=Smartphone", electronics);
            Product p2 = new Product("Laptop", "Powerful laptop for work and gaming", 1299.99, "https://placehold.co/300x200?text=Laptop", electronics);
            Product p3 = new Product("Wireless Headphones", "Noise cancelling over-ear headphones", 199.99, "https://placehold.co/300x200?text=Headphones", electronics);
            Product p4 = new Product("4K Monitor", "27-inch IPS display for professionals", 349.99, "https://placehold.co/300x200?text=Monitor", electronics);
            Product p5 = new Product("Tablet", "10-inch tablet perfect for reading and browsing", 299.99, "https://placehold.co/300x200?text=Tablet", electronics);

            // Fashion
            Product p6 = new Product("T-Shirt", "Cotton t-shirt", 19.99, "https://placehold.co/300x200?text=T-Shirt", fashion);
            Product p7 = new Product("Jeans", "Blue denim jeans", 49.99, "https://placehold.co/300x200?text=Jeans", fashion);
            Product p8 = new Product("Sneakers", "Comfortable running sneakers", 79.99, "https://placehold.co/300x200?text=Sneakers", fashion);
            Product p9 = new Product("Winter Jacket", "Warm waterproof jacket", 129.99, "https://placehold.co/300x200?text=Jacket", fashion);
            Product p10 = new Product("Sunglasses", "UV protection aviator sunglasses", 149.99, "https://placehold.co/300x200?text=Sunglasses", fashion);

            // Home
            Product p11 = new Product("Coffee Maker", "Automatic coffee maker", 89.99, "https://placehold.co/300x200?text=Coffee+Maker", home);
            Product p12 = new Product("Blender", "High-speed blender for smoothies", 59.99, "https://placehold.co/300x200?text=Blender", home);
            Product p13 = new Product("Desk Lamp", "LED desk lamp with adjustable brightness", 29.99, "https://placehold.co/300x200?text=Lamp", home);
            Product p14 = new Product("Air Purifier", "HEPA filter air purifier for large rooms", 199.99, "https://placehold.co/300x200?text=Air+Purifier", home);

            // Sports
            Product p15 = new Product("Yoga Mat", "Non-slip eco-friendly yoga mat", 24.99, "https://placehold.co/300x200?text=Yoga+Mat", sports);
            Product p16 = new Product("Dumbbells Set", "Set of 2 adjustable dumbbells", 49.99, "https://placehold.co/300x200?text=Dumbbells", sports);
            Product p17 = new Product("Running Shoes", "Lightweight shoes for marathon runners", 119.99, "https://placehold.co/300x200?text=Running+Shoes", sports);

            // Books
            Product p18 = new Product("Java Programming", "Comprehensive guide to Java development", 45.99, "https://placehold.co/300x200?text=Java+Book", books);
            Product p19 = new Product("Sci-Fi Novel", "Bestselling science fiction adventure", 15.99, "https://placehold.co/300x200?text=Novel", books);

            productRepository.saveAll(Arrays.asList(
                p1, p2, p3, p4, p5, 
                p6, p7, p8, p9, p10, 
                p11, p12, p13, p14, 
                p15, p16, p17, 
                p18, p19
            ));
        }
    }
}
