package com.shopeasy.repository;

import com.shopeasy.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Long> {
    Category findByName(String name);
}




//// client -> controllrer -> service -> repository -> database
/// out of these 5, we only have to worry about client, controller, service
/// repository and database are handled by spring boot and jpa
/// repository will have the methods to interact with database like storre, fetch, update, delete
/// we need something to call those methods that will be called from service layer