1. For fronted admin dashboard and Product add && removal support
2. Implement Authentication keep sessoins, like if user refreshes it should not be logged out
3. State management of cart, even if you login after 2 days you should see the cart as it is.
4. implement pagination for product page & add sorting logic
5. Depending upon the list of items in the cart for user, we can show the recommneded items in the home page not all. //Ai


club 1&4 for 1 session
