package com.example.security.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Admin Controller
 * 
 * Protected endpoints that require ADMIN role
 * Accessible only by users with ROLE_ADMIN
 */
@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AdminController {

    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    /**
     * Admin Dashboard Endpoint
     * 
     * GET /api/admin/dashboard
     * Requires: JWT token with ROLE_ADMIN
     */
    @GetMapping("/dashboard")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getAdminDashboard() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        log.info("Admin dashboard accessed by: {}", username);
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Admin Dashboard");
        response.put("username", username);
        response.put("description", "This is accessible only by administrators");
        response.put("privilegeLevel", "ADMIN");
        
        return ResponseEntity.ok(response);
    }

    /**
     * Manage Users Endpoint
     * 
     * GET /api/admin/users
     * Requires: JWT token with ROLE_ADMIN
     */
    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getAllUsers() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        log.info("User management accessed by: {}", username);
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "User Management");
        response.put("description", "ADMIN can view and manage all users");
        response.put("accessedBy", username);
        
        return ResponseEntity.ok(response);
    }

    /**
     * System Settings Endpoint
     * 
     * GET /api/admin/settings
     * Requires: JWT token with ROLE_ADMIN
     */
    @GetMapping("/settings")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getSystemSettings() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        log.info("System settings accessed by: {}", username);
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "System Settings");
        response.put("description", "ADMIN-only configuration panel");
        response.put("accessedBy", username);
        
        return ResponseEntity.ok(response);
    }
}
