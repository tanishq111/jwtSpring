package com.example.security.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Public Controller
 * 
 * Public endpoints that don't require authentication
 */
@RestController
@RequestMapping("/api/public")
@CrossOrigin(origins = "*", maxAge = 3600) // cors
public class PublicController {

    /**
     * Health Check Endpoint
     * 
     * GET /api/public/health
     * Public access - no authentication required
     */
    @GetMapping("/health")
    public ResponseEntity<?> healthCheck() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("message", "Application is running");
        
        return ResponseEntity.ok(response);
    }

    /**
     * Welcome Endpoint
     * 
     * GET /api/public/welcome
     * Public access - no authentication required
     */
    @GetMapping("/welcome")
    public ResponseEntity<?> welcome() {
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Welcome to Spring Security JWT Demo");
        response.put("description", "This is a public endpoint");
        
        return ResponseEntity.ok(response);
    }
}
