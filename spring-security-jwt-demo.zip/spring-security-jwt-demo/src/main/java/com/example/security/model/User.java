package com.example.security.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "user_roles", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "role")
    @Enumerated(EnumType.STRING)
    private Set<Role> roles = new HashSet<>();

    @Column(nullable = false)
    private Boolean enabled = true;


    public User() {}


    //100 parameter constructor
    //if all 100 are not compulsory some are optional // how many parametrized constructors  you have to write ?
    public User(Long id, String username, String email, String password, Set<Role> roles, Boolean enabled) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.roles = roles;
        this.enabled = enabled;
    }


    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }

    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }

    public void setPassword(String password) { this.password = password; }

    public Set<Role> getRoles() { return roles; }

    public void setRoles(Set<Role> roles) { this.roles = roles; }

    public Boolean getEnabled() { return enabled; }

    public void setEnabled(Boolean enabled) { this.enabled = enabled; }

    // ---------- Builder Pattern Implementation ----------

    // hey User.Builder please create a user object for me with the details i am giving to you
    public static class Builder {
        private Long id;
        private String username;
        private String email;
        private String password;
        private Set<Role> roles = new HashSet<>();
        private Boolean enabled = true;

        public Builder id(Long id) {
            this.id = id;
            return this;
        }
        public Builder username(String username) {
            this.username = username;
            return this;
        }
        public Builder email(String email) {
            this.email = email;
            return this;
        }
        public Builder password(String password) {
            this.password = password;
            return this;
        }
        public Builder roles(Set<Role> roles) {
            this.roles = roles;
            return this;
        }
        public Builder enabled(Boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public User build() {
            return new User(id, username, email, password, roles, enabled);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
    // user = User.builder().username("john").email("rkumar@example.com").password("password").enabled(true).build();
}
